import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
});

export const chatRooms = pgTable("chat_rooms", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  createdBy: text("created_by").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  isPrivate: boolean("is_private").default(false).notNull(),
  participants: jsonb("participants").default([]).notNull(), // List of user IDs
});

export const messages = pgTable("messages", {
  id: text("id").primaryKey(),
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  senderId: text("sender_id").notNull(),
  senderName: text("sender_name").notNull(),
  isPrivate: boolean("is_private").default(false).notNull(),
  recipientId: text("recipient_id"),
  replyToId: text("reply_to_id"),  // ID of the message this is replying to
  reactions: jsonb("reactions").default({}).notNull(), // Store reactions as JSON {emoji: [userIds]}
  chatRoomId: text("chat_room_id").default("general").notNull(), // ID of the chat room this message belongs to
});

export const insertUserSchema = createInsertSchema(users);
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const insertChatRoomSchema = createInsertSchema(chatRooms);
export type InsertChatRoom = z.infer<typeof insertChatRoomSchema>;
export type ChatRoom = typeof chatRooms.$inferSelect;

export const insertMessageSchema = createInsertSchema(messages);
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect & {
  sender: {
    id: string;
    name: string;
  };
  replyTo?: {
    id: string;
    content: string;
    sender: {
      id: string;
      name: string;
    };
  };
};

// Type for reactions
export type Reactions = Record<string, string[]>; // {emoji: [userId1, userId2]}

// Type for message reply
export type ReplyInfo = {
  messageId: string;
  originalSenderId: string;
  originalSenderName: string;
  content: string;
};

// Type for participants in a chat room
export type Participants = string[]; // Array of user IDs

// Type for active chat room
export interface ActiveChatRoom {
  id: string;
  name: string;
  messages: Message[];
  participants: string[];
  isPrivate: boolean;
};
