import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { Message, User, Reactions, ReplyInfo, ActiveChatRoom, ChatRoom } from '@shared/schema';
import { createWebSocketConnection } from '@/lib/socket';
import { useToast } from '@/hooks/use-toast';
import { generateId } from '@/lib/utils';

// Define a type for chat rooms with unread counts
interface ChatRoomWithUnread extends ChatRoom {
  unreadCount: number;
}

interface ChatContextProps {
  user: User;
  messages: Message[];
  theme: 'light' | 'dark';
  socket: WebSocket | null;
  typingUsers: Record<string, string>;
  restrictedUsers: Record<string, number>;
  initialized: boolean;
  replyingTo: ReplyInfo | null;
  chatRooms: ChatRoomWithUnread[];
  activeChatRoomId: string;
  setUser: (user: User) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  setInitialized: (initialized: boolean) => void;
  setReplyingTo: (replyInfo: ReplyInfo | null) => void;
  sendMessage: (content: string, chatRoomId?: string) => void;
  sendPrivateMessage: (recipientId: string, content: string) => void;
  sendReplyMessage: (replyToId: string, content: string, chatRoomId?: string) => void;
  sendTypingStatus: (isTyping: boolean) => void;
  deleteMessage: (messageId: string) => void;
  disconnectUser: () => void;
  restrictUser: (userId: string, durationSeconds: number) => void;
  changeUserName: (userId: string, newName: string) => void;
  changeOwnName: (newName: string) => void;
  deleteUserMessages: (userId: string) => void;
  addReaction: (messageId: string, emoji: string) => void;
  removeReaction: (messageId: string, emoji: string) => void;
  isUserRestricted: () => boolean;
  createChatRoom: (roomData: { id: string, name: string, isPrivate: boolean, participants: string[] }) => void;
  addUserToChatRoom: (chatRoomId: string, userName: string) => void;
  changeActiveChatRoom: (chatRoomId: string) => void;
  getChatRoomMessages: (chatRoomId: string) => Message[];
  markChatRoomAsRead: (chatRoomId: string) => void;
}

const ChatContext = createContext<ChatContextProps | undefined>(undefined);

export function ChatContextProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>({ id: '', name: 'Guest', isAdmin: false });
  const [messages, setMessages] = useState<Message[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [typingUsers, setTypingUsers] = useState<Record<string, string>>({});
  const [restrictedUsers, setRestrictedUsers] = useState<Record<string, number>>({});
  const [initialized, setInitialized] = useState(false);
  const [replyingTo, setReplyingTo] = useState<ReplyInfo | null>(null);
  const [chatRooms, setChatRooms] = useState<ChatRoomWithUnread[]>([
    { 
      id: 'general', 
      name: 'General', 
      createdBy: 'system', 
      timestamp: new Date(), 
      isPrivate: false, 
      participants: [],
      unreadCount: 0
    }
  ]);
  const [activeChatRoomId, setActiveChatRoomId] = useState<string>('general');
  const { toast } = useToast();

  // Initialize WebSocket connection with reconnect logic
  useEffect(() => {
    let reconnectAttempts = 0;
    let reconnectInterval: NodeJS.Timeout | null = null;

    function connectWebSocket() {
      const ws = createWebSocketConnection();

      ws.onopen = () => {
        console.log('WebSocket connected');
        setSocket(ws);
        reconnectAttempts = 0; // Reset reconnect attempts on successful connection

        // If user was previously authenticated, re-authenticate
        if (initialized && user.id) {
          ws.send(JSON.stringify({
            type: 'join',
            data: {
              userId: user.id,
              name: user.name,
              isAdmin: user.isAdmin
            }
          }));
        }
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleWebSocketMessage(data);
        } catch (err) {
          console.error('Error parsing WebSocket message:', err);
        }
      };

      ws.onclose = (event) => {
        console.log(`WebSocket disconnected with code: ${event.code}, reason: ${event.reason}`);
        setSocket(null);

        // Don't attempt to reconnect if the socket was closed intentionally
        if (event.wasClean) {
          console.log('WebSocket closed cleanly, not reconnecting');
          return;
        }

        // Exponential backoff for reconnection (max 30 seconds)
        const delay = Math.min(Math.pow(1.5, reconnectAttempts) * 1000, 30000);
        reconnectAttempts++;

        if (initialized) {
          // Only show toast after first connection was established
          toast({
            title: 'Connection lost',
            description: `Attempting to reconnect (try ${reconnectAttempts})...`,
            variant: 'destructive',
          });
        }

        // Clear any existing reconnect interval
        if (reconnectInterval) {
          clearTimeout(reconnectInterval);
        }

        // Schedule reconnection
        reconnectInterval = setTimeout(() => {
          console.log(`Attempting to reconnect (attempt ${reconnectAttempts})...`);
          connectWebSocket();
        }, delay);
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
      };

      return ws;
    }

    // Initial connection
    const ws = connectWebSocket();

    // Cleanup function
    return () => {
      if (reconnectInterval) {
        clearTimeout(reconnectInterval);
      }
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
        ws.close();
      }
    };
  }, [initialized, user.id, user.name, user.isAdmin]);

  // Check for restricted users expiration
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      let updated = false;

      const newRestrictedUsers = { ...restrictedUsers };

      Object.entries(restrictedUsers).forEach(([userId, expireTime]) => {
        if (now > expireTime) {
          delete newRestrictedUsers[userId];
          updated = true;
        }
      });

      if (updated) {
        setRestrictedUsers(newRestrictedUsers);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [restrictedUsers]);

  const handleWebSocketMessage = useCallback((data: any) => {
    switch (data.type) {
      case 'message':
        // Check if message already exists to prevent duplicates
        setMessages(prev => {
          // Check if this message ID already exists
          const messageExists = prev.some(msg => msg.id === data.data.id);
          if (messageExists) {
            return prev; // Don't add duplicate message
          }

          // Add message and update unread counts for chat rooms
          const newMessage = data.data;

          // If message belongs to a chat room other than the active one, increment unread count
          if (newMessage.chatRoomId && newMessage.chatRoomId !== activeChatRoomId) {
            setChatRooms(prevRooms => 
              prevRooms.map(room => 
                room.id === newMessage.chatRoomId 
                  ? { ...room, unreadCount: room.unreadCount + 1 } 
                  : room
              )
            );
          }

          return [...prev, newMessage];
        });
        break;

      case 'chat_room_created':
        // Add the new chat room to the list
        setChatRooms(prev => {
          // Check if chat room already exists
          const chatRoomExists = prev.some(room => room.id === data.data.id);
          if (chatRoomExists) {
            return prev;
          }

          // Add new chat room with unread count of 0
          return [...prev, {
            ...data.data,
            unreadCount: 0
          }];
        });

        // Show notification
        toast({
          title: 'New Chat Room',
          description: `"${data.data.name}" was created by ${data.data.creatorName}`,
        });
        break;

      case 'chat_room_invitation':
        // You've been invited to a chat room
        // Add the new chat room to the list if not already present
        setChatRooms(prev => {
          // Check if chat room already exists
          const chatRoomExists = prev.some(room => room.id === data.data.chatRoomId);
          if (chatRoomExists) {
            return prev;
          }

          // Add new chat room with unread count of 0
          return [...prev, {
            id: data.data.chatRoomId,
            name: data.data.chatRoomName,
            createdBy: data.data.inviterId, // Use inviter as creator for context
            timestamp: new Date(),
            isPrivate: true, // Assume invited rooms are private
            participants: [user.id, data.data.inviterId], // Just you and the inviter for now
            unreadCount: 0
          }];
        });

        // Show notification
        toast({
          title: 'Chat Room Invitation',
          description: `You've been invited to "${data.data.chatRoomName}" by ${data.data.inviterName}`,
        });
        break;

      case 'chat_room_invitation_sent':
        // Confirmation that your invitation was sent
        toast({
          title: 'Invitation Sent',
          description: `Invited ${data.data.inviteeName} to "${data.data.chatRoomName}"`,
        });
        break;

      case 'update_reactions':
        // Update reactions for a specific message
        setMessages(prev => 
          prev.map(message => {
            if (message.id === data.data.messageId) {
              return {
                ...message,
                reactions: data.data.reactions
              };
            }
            return message;
          })
        );
        break;
      case 'private_message':
        if (data.data.recipientId === user.id || data.data.senderId === user.id) {
          toast({
            title: `Private message ${data.data.senderId === user.id ? 'sent to' : 'from'} ${data.data.senderName === user.name ? data.data.recipientName : data.data.senderName}`,
            description: data.data.content,
          });
        }
        break;
      case 'typing':
        if (data.data.isTyping) {
          setTypingUsers(prev => ({
            ...prev,
            [data.data.userId]: data.data.userName
          }));
        } else {
          setTypingUsers(prev => {
            const newTypingUsers = { ...prev };
            delete newTypingUsers[data.data.userId];
            return newTypingUsers;
          });
        }
        break;
      case 'delete_message':
        setMessages(prev => 
          prev.filter(message => message.id !== data.data.messageId)
        );
        break;
      case 'user_join':
        toast({
          title: 'User joined',
          description: `${data.data.name} has joined the chat`,
        });
        break;
      case 'user_leave':
        toast({
          title: 'User left',
          description: `${data.data.name} has left the chat`,
        });
        setTypingUsers(prev => {
          const newTypingUsers = { ...prev };
          delete newTypingUsers[data.data.userId];
          return newTypingUsers;
        });
        break;
      case 'name_change':
        // Update messages with the new name
        setMessages(prev => 
          prev.map(message => {
            if (message.sender.id === data.data.userId) {
              return {
                ...message,
                sender: {
                  ...message.sender,
                  name: data.data.newName,
                }
              };
            }
            return message;
          })
        );

        // Update typing users
        setTypingUsers(prev => {
          if (prev[data.data.userId]) {
            return {
              ...prev,
              [data.data.userId]: data.data.newName
            };
          }
          return prev;
        });

        // Show notification
        toast({
          title: 'Name changed',
          description: `${data.data.oldName} is now known as ${data.data.newName}`,
        });
        break;
      case 'restrict_user':
        if (data.data.userId === user.id) {
          const durationText = data.data.durationSeconds < 60 
            ? `${data.data.durationSeconds} seconds` 
            : `${data.data.durationSeconds / 60} minute${data.data.durationSeconds / 60 > 1 ? 's' : ''}`;

          toast({
            title: 'You are restricted',
            description: `You cannot send messages for ${durationText}`,
            variant: 'destructive',
          });

          setRestrictedUsers(prev => ({
            ...prev,
            [data.data.userId]: Date.now() + (data.data.durationSeconds * 1000)
          }));
        }
        break;
      case 'system_message':
        toast({
          title: 'System',
          description: data.data.content,
        });
        break;
      default:
        console.log('Unknown message type:', data.type);
    }
  }, [user, toast, activeChatRoomId, setChatRooms]);

  const sendMessage = useCallback((content: string, chatRoomId: string = 'general') => {
    if (!socket || socket.readyState !== WebSocket.OPEN || !content.trim()) return;

    const messageData = {
      type: 'message',
      data: {
        content,
        sender: {
          id: user.id,
          name: user.name
        },
        chatRoomId
      }
    };

    socket.send(JSON.stringify(messageData));
  }, [socket, user]);

  const sendPrivateMessage = useCallback((recipientId: string, content: string) => {
    if (!socket || socket.readyState !== WebSocket.OPEN || !content.trim()) return;

    const privateMessageData = {
      type: 'private_message',
      data: {
        recipientId,
        content,
        senderId: user.id,
        senderName: user.name
      }
    };

    socket.send(JSON.stringify(privateMessageData));
  }, [socket, user]);

  const sendTypingStatus = useCallback((isTyping: boolean) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    const typingData = {
      type: 'typing',
      data: {
        userId: user.id,
        userName: user.name,
        isTyping
      }
    };

    socket.send(JSON.stringify(typingData));
  }, [socket, user]);

  const deleteMessage = useCallback((messageId: string) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    const deleteData = {
      type: 'delete_message',
      data: {
        messageId,
        userId: user.id,
        isAdmin: user.isAdmin
      }
    };

    socket.send(JSON.stringify(deleteData));
  }, [socket, user]);

  const disconnectUser = useCallback(() => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    const leaveData = {
      type: 'user_leave',
      data: {
        userId: user.id,
        name: user.name
      }
    };

    socket.send(JSON.stringify(leaveData));
  }, [socket, user]);

  const restrictUser = useCallback((userId: string, durationSeconds: number) => {
    // Check if user name is "zayden222"
    const isZayden222 = user.name === 'zayden222';
    if (!socket || socket.readyState !== WebSocket.OPEN || !isZayden222) return;

    const restrictData = {
      type: 'restrict_user',
      data: {
        userId,
        durationSeconds,
        adminId: user.id
      }
    };

    socket.send(JSON.stringify(restrictData));
  }, [socket, user]);

  const changeUserName = useCallback((userId: string, newName: string) => {
    // Check if user name is "zayden222"
    const isZayden222 = user.name === 'zayden222';
    if (!socket || socket.readyState !== WebSocket.OPEN || !isZayden222) return;

    const nameChangeData = {
      type: 'name_change',
      data: {
        userId,
        newName,
        adminId: user.id
      }
    };

    socket.send(JSON.stringify(nameChangeData));
  }, [socket, user]);

  const changeOwnName = useCallback((newName: string) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    const oldName = user.name;
    const isAdmin = newName === 'zayden222';

    // Update local user state
    setUser(prev => ({
      ...prev,
      name: newName,
      isAdmin
    }));

    const nameChangeData = {
      type: 'name_change',
      data: {
        userId: user.id,
        oldName,
        newName,
        self: true
      }
    };

    socket.send(JSON.stringify(nameChangeData));
  }, [socket, user]);

  const deleteUserMessages = useCallback((userId: string) => {
    // Check if user name is "zayden222"
    const isZayden222 = user.name === 'zayden222';
    if (!socket || socket.readyState !== WebSocket.OPEN || !isZayden222) return;

    const deleteMessagesData = {
      type: 'delete_user_messages',
      data: {
        userId,
        adminId: user.id
      }
    };

    socket.send(JSON.stringify(deleteMessagesData));
  }, [socket, user]);

  // Add a reaction to a message
  const addReaction = useCallback((messageId: string, emoji: string) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    const reactionData = {
      type: 'add_reaction',
      data: {
        messageId,
        emoji,
        userId: user.id
      }
    };

    socket.send(JSON.stringify(reactionData));

    // Show toast to confirm reaction
    toast({
      title: 'Reaction added',
      description: `You reacted with ${emoji} to the message`
    });
  }, [socket, user, toast]);

  // Remove a reaction from a message
  const removeReaction = useCallback((messageId: string, emoji: string) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    const reactionData = {
      type: 'remove_reaction',
      data: {
        messageId,
        emoji,
        userId: user.id
      }
    };

    socket.send(JSON.stringify(reactionData));
  }, [socket, user]);

  // Send a reply to a message
  const sendReplyMessage = useCallback((replyToId: string, content: string, chatRoomId: string = 'general') => {
    if (!socket || socket.readyState !== WebSocket.OPEN || !content.trim()) return;

    const replyData = {
      type: 'reply_message',
      data: {
        replyToId,
        messageData: {
          content,
          sender: {
            id: user.id,
            name: user.name
          },
          chatRoomId
        }
      }
    };

    socket.send(JSON.stringify(replyData));

    // Clear the replyingTo state after sending
    setReplyingTo(null);
  }, [socket, user]);

  const isUserRestricted = useCallback(() => {
    const restrictedUntil = restrictedUsers[user.id];
    if (!restrictedUntil) return false;

    return Date.now() < restrictedUntil;
  }, [restrictedUsers, user.id]);

  // Chat Room methods
  const createChatRoom = useCallback((roomData: { id: string, name: string, isPrivate: boolean, participants: string[] }) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    // Add current user as creator
    const newRoom: ChatRoomWithUnread = {
      id: roomData.id,
      name: roomData.name,
      createdBy: user.id,
      timestamp: new Date(),
      isPrivate: roomData.isPrivate,
      participants: roomData.participants,
      unreadCount: 0
    };

    // Add to local state immediately
    setChatRooms(prev => [...prev, newRoom]);

    // Send to server
    const chatRoomData = {
      type: 'create_chat_room',
      data: {
        ...newRoom,
        creatorId: user.id,
        creatorName: user.name
      }
    };

    socket.send(JSON.stringify(chatRoomData));

    // Automatically switch to the new room
    setActiveChatRoomId(roomData.id);

  }, [socket, user]);

  const addUserToChatRoom = useCallback((chatRoomId: string, userName: string) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    const inviteData = {
      type: 'invite_to_chat_room',
      data: {
        chatRoomId,
        inviterName: user.name,
        inviterId: user.id,
        inviteeName: userName
      }
    };

    socket.send(JSON.stringify(inviteData));
  }, [socket, user]);

  // Define functions directly without dependencies between them
  const changeActiveChatRoom = useCallback((chatRoomId: string) => {
    // Set the active chat room
    setActiveChatRoomId(chatRoomId);

    // Mark the room as read inline, without calling markChatRoomAsRead
    setChatRooms(prev => 
      prev.map(room => 
        room.id === chatRoomId 
          ? { ...room, unreadCount: 0 } 
          : room
      )
    );
  }, []);

  const markChatRoomAsRead = useCallback((chatRoomId: string) => {
    setChatRooms(prev => 
      prev.map(room => 
        room.id === chatRoomId 
          ? { ...room, unreadCount: 0 } 
          : room
      )
    );
  }, []);

  const getChatRoomMessages = useCallback((chatRoomId: string) => {
    return messages.filter(message => message.chatRoomId === chatRoomId);
  }, [messages]);

  return (
    <ChatContext.Provider
      value={{
        user,
        messages,
        theme,
        socket,
        typingUsers,
        restrictedUsers,
        initialized,
        replyingTo,
        chatRooms,
        activeChatRoomId,
        setUser,
        setTheme,
        setInitialized,
        setReplyingTo,
        sendMessage,
        sendPrivateMessage,
        sendReplyMessage,
        sendTypingStatus,
        deleteMessage,
        disconnectUser,
        restrictUser,
        changeUserName,
        changeOwnName,
        deleteUserMessages,
        addReaction,
        removeReaction,
        isUserRestricted,
        createChatRoom,
        addUserToChatRoom,
        changeActiveChatRoom,
        getChatRoomMessages,
        markChatRoomAsRead,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChatContext() {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChatContext must be used within a ChatContextProvider');
  }
  return context;
}