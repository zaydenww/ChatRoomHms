export function createWebSocketConnection() {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const wsUrl = `${protocol}//${window.location.host}/ws`;
  
  console.log(`Connecting to WebSocket at ${wsUrl}`);
  
  try {
    const socket = new WebSocket(wsUrl);
    
    // Log connection states
    socket.addEventListener('open', () => {
      console.log('WebSocket connection established successfully');
    });
    
    // Handle errors without recursive retries (prevents memory leaks)
    socket.addEventListener('error', (error) => {
      console.error('WebSocket connection error:', error);
    });
    
    socket.addEventListener('close', (event) => {
      console.log(`WebSocket disconnected with code: ${event.code}, reason: ${event.reason}`);
    });
    
    return socket;
  } catch (error) {
    console.error('Failed to create WebSocket connection:', error);
    
    // Create and return a dummy WebSocket-like object to prevent app crashes
    // This allows the app to continue functioning and show appropriate error messages
    const dummySocket = new EventTarget() as WebSocket;
    
    // Add stub methods to prevent errors when these methods are called
    dummySocket.send = (data: string) => {
      console.warn('Attempted to send message on disconnected WebSocket:', data);
    };
    
    dummySocket.close = () => {
      console.warn('Attempted to close already disconnected WebSocket');
    };
    
    // Return readyState as CLOSED
    Object.defineProperty(dummySocket, 'readyState', {
      get: () => WebSocket.CLOSED
    });
    
    return dummySocket;
  }
}
