import { useState, useEffect, useRef } from "react";
import { useChatContext } from "@/context/ChatContext";
import { Button } from "@/components/ui/button";
import MessageBubble from "@/components/chat/MessageBubble";
import MessageInput from "@/components/chat/MessageInput";
import SystemMessage from "@/components/chat/SystemMessage";
import TypingIndicator from "@/components/chat/TypingIndicator";
import AdminModal from "@/components/chat/AdminModal";
import PrivateMessageModal from "@/components/chat/PrivateMessageModal";
import NicknameModal from "@/components/chat/NicknameModal";
import ProfileModal from "@/components/chat/ProfileModal";
import ChatRoomTabs from "@/components/chat/ChatRoomTabs";
import ChatRoomInviteModal from "@/components/chat/ChatRoomInviteModal";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Moon, Sun, User, LogOut, Edit, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Chat() {
  const { 
    user, 
    messages, 
    theme, 
    setTheme, 
    socket, 
    typingUsers, 
    disconnectUser,
    chatRooms,
    activeChatRoomId,
    changeActiveChatRoom,
    getChatRoomMessages,
    sendPrivateMessage
  } = useChatContext();
  
  const { toast } = useToast();
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isPrivateModalOpen, setIsPrivateModalOpen] = useState(false);
  const [isNicknameModalOpen, setIsNicknameModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState(false);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<{id: string, name: string} | null>(null);
  const [longPressTimer, setLongPressTimer] = useState<NodeJS.Timeout | null>(null);
  const messageContainerRef = useRef<HTMLDivElement>(null);
  
  // Get current chat room's messages
  const currentRoomMessages = getChatRoomMessages(activeChatRoomId);
  const currentChatRoom = chatRooms.find(room => room.id === activeChatRoomId);

  useEffect(() => {
    if (messageContainerRef.current) {
      messageContainerRef.current.scrollTop = messageContainerRef.current.scrollHeight;
    }
  }, [currentRoomMessages, typingUsers]);

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  const handleLogout = () => {
    disconnectUser();
    window.location.reload();
  };

  const handleUserNameClick = (userId: string, userName: string) => {
    // Check if current user is "zayden" (case insensitive)
    if (user.name.toLowerCase() === "zayden" && user.isAdmin) {
      setSelectedUser({ id: userId, name: userName });
      setIsAdminModalOpen(true);
    }
  };

  const handleUserNameMouseDown = (userId: string, userName: string) => {
    // Don't set long press for your own name
    if (userId === user.id) return;
    
    // Setup long press
    const timer = setTimeout(() => {
      setSelectedUser({ id: userId, name: userName });
      setIsPrivateModalOpen(true);
    }, 2000); // 2 seconds for long press
    
    setLongPressTimer(timer);
  };

  const handleUserNameMouseUp = () => {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      setLongPressTimer(null);
    }
  };

  // Handle touch events for mobile
  const handleTouchStart = (userId: string, userName: string) => {
    handleUserNameMouseDown(userId, userName);
  };

  const handleTouchEnd = () => {
    handleUserNameMouseUp();
  };

  const openNicknameModal = () => {
    setIsNicknameModalOpen(true);
    setIsUserDropdownOpen(false);
  };

  const openProfileModal = () => {
    setIsProfileModalOpen(true);
    setIsUserDropdownOpen(false);
  };

  // Check connection status
  const isConnected = socket && socket.readyState === WebSocket.OPEN;

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <header className="bg-card shadow-sm z-10 sticky top-0">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-primary">Message App</h1>
            <div className="ml-3 flex items-center">
              <div className={`h-2 w-2 rounded-full mr-1 ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-xs text-muted-foreground">
                {isConnected ? 'Connected' : 'Reconnecting...'}
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleTheme} 
              className="rounded-full"
            >
              {theme === "dark" ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </Button>
            <Popover open={isUserDropdownOpen} onOpenChange={setIsUserDropdownOpen}>
              <PopoverTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2 focus:outline-none">
                  <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-medium">
                    {user.name.substring(0, 2).toUpperCase()}
                  </div>
                  <span className="text-sm font-medium hidden sm:inline-block">
                    {user.name}
                  </span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-48 p-1">
                <div className="space-y-1">
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-sm"
                    onClick={openProfileModal}
                  >
                    <Mail className="mr-2 h-4 w-4" />
                    Profile & Email
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-sm"
                    onClick={openNicknameModal}
                  >
                    <Edit className="mr-2 h-4 w-4" />
                    Change Nickname
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-sm"
                    onClick={handleLogout}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Log Out
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </header>

      {/* Message Container */}
      <main className="flex-1 overflow-hidden flex flex-col">
        {/* Chat Room Tabs */}
        <ChatRoomTabs 
          activeChatRoom={activeChatRoomId} 
          onChangeRoom={changeActiveChatRoom}
        />
        
        <div 
          ref={messageContainerRef}
          className="flex-1 overflow-y-auto p-4" 
          id="message-container"
        >
          <div className="max-w-screen-lg mx-auto space-y-3">
            {/* Welcome message always appears first */}
            <div className="flex justify-center my-4">
              <SystemMessage text={`Welcome to ${currentChatRoom?.name || 'the chat'}!`} />
            </div>
            
            {/* Message list */}
            <div className="flex flex-col space-y-1">
              {currentRoomMessages.map((message) => (
                <MessageBubble
                  key={message.id}
                  message={message}
                  currentUser={user}
                  messages={messages}
                  onUserNameClick={handleUserNameClick}
                  onUserNameMouseDown={handleUserNameMouseDown}
                  onUserNameMouseUp={handleUserNameMouseUp}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  sendPrivateMessage={sendPrivateMessage}
                />
              ))}
            </div>
            
            {/* Typing indicators */}
            {Object.keys(typingUsers).length > 0 && (
              <div className="flex flex-col space-y-1">
                {Object.entries(typingUsers)
                  .filter(([userId]) => userId !== user.id)
                  .map(([userId, userName]) => (
                    <TypingIndicator key={`typing-${userId}`} userName={userName} />
                  ))
                }
              </div>
            )}
          </div>
        </div>
        
        {/* Message Input with New Chat Button */}
        <MessageInput 
          onNewChatClick={() => setIsNewChatModalOpen(true)}
          chatRoomId={activeChatRoomId}
        />
      </main>

      {/* Modals */}
      <AdminModal 
        isOpen={isAdminModalOpen} 
        onClose={() => setIsAdminModalOpen(false)} 
        selectedUser={selectedUser} 
      />
      
      <PrivateMessageModal 
        isOpen={isPrivateModalOpen} 
        onClose={() => setIsPrivateModalOpen(false)} 
        recipient={selectedUser} 
      />
      
      <NicknameModal 
        isOpen={isNicknameModalOpen} 
        onClose={() => setIsNicknameModalOpen(false)} 
      />
      
      {/* Chat Room Invite Modal */}
      <ChatRoomInviteModal
        isOpen={isInviteModalOpen}
        onClose={() => setIsInviteModalOpen(false)}
        chatRoomId={activeChatRoomId}
        chatRoomName={currentChatRoom?.name || 'the chat'}
      />

      {/* Profile Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />
    </div>
  );
}
