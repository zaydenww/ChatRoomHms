import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useChatContext } from "@/context/ChatContext";
import { useToast } from "@/hooks/use-toast";

export default function Welcome() {
  const [nickname, setNickname] = useState("");
  const { setUser, socket, setInitialized } = useChatContext();
  const { toast } = useToast();
  
  // Check if a saved user ID and name exist
  useEffect(() => {
    const savedUserId = localStorage.getItem('user_id');
    if (savedUserId) {
      const savedUsername = localStorage.getItem(`user_${savedUserId}_username`);
      if (savedUsername) {
        setNickname(savedUsername);
      }
    }
  }, []);

  const handleJoinChat = () => {
    if (!nickname.trim()) {
      toast({
        title: "Nickname required",
        description: "Please enter a nickname to join the chat",
        variant: "destructive",
      });
      return;
    }

    // Generate a user ID or load from localStorage
    let userId = localStorage.getItem('user_id');
    if (!userId) {
      userId = Math.random().toString(36).substring(2, 15);
      localStorage.setItem('user_id', userId);
    }
    
    const isAdmin = nickname === "zayden222";
    const displayName = nickname === "zayden222" ? "zayden" : nickname;

    // Save user name to localStorage for future sessions
    localStorage.setItem(`user_${userId}_username`, displayName);
    
    // Set up default chat history saving preference
    if (localStorage.getItem(`user_${userId}_saveChats`) === null) {
      localStorage.setItem(`user_${userId}_saveChats`, 'true');
    }
    
    // Create a chat history record
    const chatHistory = {
      lastSeen: new Date().toISOString(),
      userId: userId
    };
    localStorage.setItem(`chat_history_${userId}`, JSON.stringify(chatHistory));

    // Set user in context
    setUser({
      id: userId,
      name: displayName,
      isAdmin,
    });

    // Send join message to server
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: "join",
        data: {
          userId,
          name: displayName,
          isAdmin,
        }
      }));
    }

    setInitialized(true);

    toast({
      title: "Welcome to the chat!",
      description: `You've joined as ${displayName}`,
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleJoinChat();
    }
  };

  return (
    <div className="fixed inset-0 bg-background flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="pt-6 space-y-4">
          <h1 className="text-2xl font-bold text-center mb-6">Welcome to Message App</h1>

          <div>
            <Label htmlFor="nickname" className="block text-sm font-medium mb-1">
              Enter your nickname
            </Label>
            <Input
              id="nickname"
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Your name"
              className="w-full"
            />
          </div>

          <Button 
            className="w-full" 
            onClick={handleJoinChat}
          >
            Join Chat
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}