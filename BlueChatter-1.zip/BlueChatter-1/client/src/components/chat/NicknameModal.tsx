import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useChatContext } from "@/context/ChatContext";
import { X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface NicknameModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function NicknameModal({ isOpen, onClose }: NicknameModalProps) {
  const [newNickname, setNewNickname] = useState("");
  const { user, changeOwnName } = useChatContext();
  const { toast } = useToast();

  const handleUpdateNickname = () => {
    if (!newNickname.trim()) {
      toast({
        title: "Invalid nickname",
        description: "Nickname cannot be empty",
        variant: "destructive",
      });
      return;
    }

    const oldName = user.name;
    changeOwnName(newNickname);
    
    toast({
      title: "Nickname updated",
      description: `Your nickname has been changed from ${oldName} to ${newNickname}`,
    });
    
    setNewNickname("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium">
            Change Your Nickname
          </DialogTitle>
          <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </DialogClose>
        </DialogHeader>
        
        <Input
          value={newNickname}
          onChange={(e) => setNewNickname(e.target.value)}
          placeholder="New nickname"
        />
        
        <DialogFooter>
          <Button onClick={handleUpdateNickname} className="w-full">
            Update Nickname
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
