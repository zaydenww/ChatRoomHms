import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { useChatContext } from "@/lib/chat-context";
import { useToast } from "@/hooks/use-toast";
import { Clock, Edit, MessageSquareX, Shield } from "lucide-react";

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedUser: { id: string; name: string } | null;
}

const ADMIN_EMAILS = ['zaydenwattsyt@gmail.com', 'rtavant722@dcsdschools.org'];

export default function AdminModal({ isOpen, onClose, selectedUser }: AdminModalProps) {
  const [newDisplayName, setNewDisplayName] = useState("");
  const [selectedTab, setSelectedTab] = useState("name");
  const { restrictUser, changeUserName, deleteUserMessages } = useChatContext();
  const { toast } = useToast();

  if (!selectedUser) return null;

  const handleRestrictTyping = (duration: number) => {
    restrictUser(selectedUser.id, duration);

    const durationText = 
      duration < 60 
        ? `${duration} seconds` 
        : `${duration / 60} minute${duration / 60 > 1 ? 's' : ''}`;

    toast({
      title: "User restricted",
      description: `${selectedUser.name} can't type for ${durationText}`,
    });

    onClose();
  };

  const handleUpdateDisplayName = () => {
    if (!newDisplayName.trim()) {
      toast({
        title: "Invalid name",
        description: "Display name cannot be empty",
        variant: "destructive",
      });
      return;
    }

    changeUserName(selectedUser.id, newDisplayName);

    toast({
      title: "Name updated",
      description: `Changed ${selectedUser.name}'s name to ${newDisplayName}`,
    });

    setNewDisplayName("");
    onClose();
  };

  const handleDeleteMessages = () => {
    deleteUserMessages(selectedUser.id);

    toast({
      title: "Messages deleted",
      description: `All messages from ${selectedUser.name} have been deleted`,
    });

    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-500" />
            Moderate User: {selectedUser.name}
          </DialogTitle>
          <DialogDescription>
            Manage user restrictions and settings
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="name" className="w-full" value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="name">Name</TabsTrigger>
            <TabsTrigger value="restrict">Restrict</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
          </TabsList>

          <TabsContent value="name">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">Change Display Name</CardTitle>
                <CardDescription>Update user's display name</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <Input
                    placeholder="New display name"
                    value={newDisplayName}
                    onChange={(e) => setNewDisplayName(e.target.value)}
                  />
                  <Button onClick={handleUpdateDisplayName}>
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="restrict">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">
                  <Clock className="h-4 w-4 inline mr-2" />
                  Restrict Typing
                </CardTitle>
                <CardDescription>
                  Temporarily prevent user from sending messages
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    variant="outline" 
                    onClick={() => handleRestrictTyping(30)}
                    className="flex items-center justify-center"
                  >
                    30 Seconds
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleRestrictTyping(60)}
                    className="flex items-center justify-center"
                  >
                    1 Minute
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleRestrictTyping(300)}
                    className="flex items-center justify-center"
                  >
                    5 Minutes
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleRestrictTyping(600)}
                    className="flex items-center justify-center"
                  >
                    10 Minutes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center text-destructive">
                  <MessageSquareX className="h-4 w-4 mr-2" />
                  Message Controls
                </CardTitle>
                <CardDescription>
                  Delete all messages from this user
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="destructive" 
                  className="w-full" 
                  onClick={handleDeleteMessages}
                >
                  Delete All Messages
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}