interface SystemMessageProps {
  text: string;
}

export default function SystemMessage({ text }: SystemMessageProps) {
  return (
    <div className="flex justify-center my-4">
      <div className="system-message">
        {text}
      </div>
    </div>
  );
}
