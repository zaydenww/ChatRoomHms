
import { useState, useRef } from 'react';
import { Message } from '@/types';
import { PrivateMessageModal } from './PrivateMessageModal';

interface MessageComponentProps {
  message: Message;
}

export function MessageComponent({ message }: MessageComponentProps) {
  const [showPrivateModal, setShowPrivateModal] = useState(false);
  const longPressTimer = useRef<NodeJS.Timeout>();
  const isLongPress = useRef(false);

  const handleMouseDown = () => {
    isLongPress.current = false;
    longPressTimer.current = setTimeout(() => {
      isLongPress.current = true;
      setShowPrivateModal(true);
    }, 500); // 500ms for long press
  };

  const handleMouseUp = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
  };

  const handleTouchStart = () => {
    isLongPress.current = false;
    longPressTimer.current = setTimeout(() => {
      isLongPress.current = true;
      setShowPrivateModal(true);
    }, 500);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
  };

  return (
    <div
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className="message-container"
    >
      <div className={`message-bubble-${message.senderId === user.id ? 'out' : 'in'}`}>
        <div className="font-semibold text-sm">{message.senderName}</div>
        <div>{message.content}</div>
      </div>

      <PrivateMessageModal 
        isOpen={showPrivateModal}
        onClose={() => setShowPrivateModal(false)}
        recipient={{
          id: message.senderId,
          name: message.senderName
        }}
      />
    </div>
  );
}
