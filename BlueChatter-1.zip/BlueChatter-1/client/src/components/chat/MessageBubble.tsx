import { Message, User, ReplyInfo, Reactions } from "@shared/schema";
import { Trash, Reply, SmilePlus, MessageSquare } from "lucide-react";
import { useChatContext } from "@/context/ChatContext";
import { Badge } from "@/components/ui/badge";
import { useRef, useState, useEffect, ReactNode } from "react";
import { useToast } from "@/hooks/use-toast";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

// Simple function to format timestamp
const formatTime = (timestamp: string | number | Date): string => {
  try {
    const date = timestamp instanceof Date 
      ? timestamp 
      : typeof timestamp === 'string' 
        ? new Date(timestamp) 
        : new Date(Number(timestamp));

    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch (error) {
    console.error('Error formatting timestamp:', error);
    return '00:00';
  }
};

interface MessageBubbleProps {
  message: Message;
  currentUser: User;
  onUserNameClick: (userId: string, userName: string) => void;
  onUserNameMouseDown: (userId: string, userName: string) => void;
  onUserNameMouseUp: () => void;
  onTouchStart: (userId: string, userName: string) => void;
  onTouchEnd: () => void;
  messages: Message[]; // Add messages array for finding user names
  sendPrivateMessage: (userId: string, message: string) => void; // Add sendPrivateMessage function
}

export default function MessageBubble({
  message,
  currentUser,
  onUserNameClick,
  onUserNameMouseDown,
  onUserNameMouseUp,
  onTouchStart,
  onTouchEnd,
  messages,
  sendPrivateMessage,
}: MessageBubbleProps) {
  const { deleteMessage, addReaction, removeReaction, setReplyingTo } = useChatContext();
  const [isHovered, setIsHovered] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const { toast } = useToast();
  const messageRef = useRef<HTMLDivElement>(null);

  // Double tap for private message functionality
  const [lastTap, setLastTap] = useState(0);
  const [selectedForPrivate, setSelectedForPrivate] = useState(false);

  // Hold-to-select functionality
  const [holdTimer, setHoldTimer] = useState<NodeJS.Timeout | null>(null);
  const [isHolding, setIsHolding] = useState(false);
  const HOLD_DURATION = 500; // ms for hold detection

  const isOwnMessage = message.sender.id === currentUser.id;
  const isAdmin = false;
  const isCurrentUserAdmin = false;

  // Common emoji reactions
  const commonEmojis = ["👍", "❤️", "😂", "😮", "😢", "🔥", "👏", "🎉"];

  // Start holding timer
  const startHoldTimer = (userId: string, userName: string) => {
    // Don't activate for own messages
    if (userId === currentUser.id) return;

    // Clear any existing timer
    if (holdTimer) clearTimeout(holdTimer);

    // Set new hold timer
    const timer = setTimeout(() => {
      setIsHolding(true);
      // Open private message modal after hold duration
      onUserNameClick(userId, userName);
    }, HOLD_DURATION);

    setHoldTimer(timer);
  };

  // Cancel holding timer
  const cancelHoldTimer = () => {
    if (holdTimer) {
      clearTimeout(holdTimer);
      setHoldTimer(null);
    }
    setIsHolding(false);
  };

  const [showPrivateMessageForm, setShowPrivateMessageForm] = useState(false);
  const [privateMessage, setPrivateMessage] = useState("");


  const handleMessageAction = (action: string) => {
    switch (action) {
      case "delete":
        if (isOwnMessage || isCurrentUserAdmin) {
          deleteMessage(message.id);
          toast({
            title: "Message deleted",
            description: "The message has been removed"
          });
        }
        break;
      case "reply":
        const replyInfo: ReplyInfo = {
          messageId: message.id,
          originalSenderId: message.sender.id,
          originalSenderName: message.sender.name,
          content: message.content.startsWith('data:image') ? '[Image]' : message.content
        };
        setReplyingTo(replyInfo);
        toast({
          title: "Reply mode activated",
          description: `Replying to ${message.sender.name}`
        });
        break;
      case "whisper":
        setShowPrivateMessageForm(true);
        break;
      default:
        break;
    }
  };

  const handlePrivateMessageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (privateMessage.trim()) {
      sendPrivateMessage(message.sender.id, privateMessage);
      setPrivateMessage("");
      setShowPrivateMessageForm(false);
    }
  };

  const handleEmojiSelect = (emoji: string) => {
    addReaction(message.id, emoji);
    setShowEmojiPicker(false);
  };

  // Toggle a reaction (add/remove)
  const toggleReaction = (emoji: string) => {
    // Cast the reactions to proper type from schema
    const reactions = (message.reactions as Reactions) || {};
    const reactionsForEmoji = reactions[emoji] || [];
    if (reactionsForEmoji.includes(currentUser.id)) {
      removeReaction(message.id, emoji);
    } else {
      addReaction(message.id, emoji);
    }
  };

  // Handle direct click on message for admin deletion or double-tap for private message
  const handleMessageClick = () => {
    // If admin clicking on someone else's message for deletion
    if (isCurrentUserAdmin && !isOwnMessage) {
      const shouldDelete = confirm("Delete this message?");
      if (shouldDelete) {
        deleteMessage(message.id);
        toast({
          title: "Message deleted",
          description: "The message has been removed"
        });
      }
      return;
    }

    // Handle double tap for private messaging
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300; // 300ms

    if (now - lastTap < DOUBLE_TAP_DELAY && !isOwnMessage) {
      // This is a double tap - open private message
      setSelectedForPrivate(true);
      onUserNameClick(message.sender.id, message.sender.name);
    }

    setLastTap(now);
  };

  // Reset private message selection when modal is closed
  useEffect(() => {
    return () => {
      setSelectedForPrivate(false);
    };
  }, []);

  const renderMessageContent = (): React.ReactNode => {
    // Determine if the message contains an image (base64 string)
    if (message.content && typeof message.content === 'string' && message.content.startsWith('data:image')) {
      return (
        <div className="image-container">
          <img 
            src={message.content} 
            alt="Shared image" 
            className="message-image" 
            onClick={(e) => {
              // Prevent image click from triggering message actions
              e.stopPropagation();
              // Open image in new tab or modal for full view
              window.open(message.content, '_blank');
            }}
            onLoad={() => {
              // Force scroll to bottom when image loads
              const messageContainer = document.getElementById('message-container');
              if (messageContainer) {
                messageContainer.scrollTop = messageContainer.scrollHeight;
              }
            }}
          />
        </div>
      );
    }

    // Regular text message - ensure it's converted to a string
    const content = message.content;
    return <span>{content && typeof content === 'string' ? content : String(content || '')}</span>;
  };

  return (
    <div
      className={`flex flex-col ${isOwnMessage ? "items-end" : "items-start"} mb-3 message-wrapper`}
      data-user={message.sender.name}
    >
      <div 
        className={`flex ${isOwnMessage ? "justify-end" : "justify-start"} space-x-2 group`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className={`max-w-xs sm:max-w-md ${isOwnMessage ? "order-2" : ""}`}>
          <div className={`flex flex-col ${isOwnMessage ? "items-end" : "items-start"}`}>
            <div className="flex items-center mb-1">
              {!isOwnMessage ? (
                <>
                  <span
                    className="text-xs font-medium text-muted-foreground cursor-pointer select-none"
                    onClick={() => onUserNameClick(message.sender.id, message.sender.name)}
                    onMouseDown={() => startHoldTimer(message.sender.id, message.sender.name)}
                    onMouseUp={cancelHoldTimer}
                    onMouseLeave={cancelHoldTimer}
                    onTouchStart={() => startHoldTimer(message.sender.id, message.sender.name)}
                    onTouchEnd={cancelHoldTimer}
                  >
                    {message.sender.name}
                  </span>
                  <span className="text-xs text-muted-foreground ml-2">
                    {formatTime(message.timestamp)}
                  </span>
                  {isAdmin && (
                    <Badge className="ml-2 text-xs" variant="secondary">
                      Admin
                    </Badge>
                  )}
                </>
              ) : (
                <>
                  <span className="text-xs text-muted-foreground mr-2">
                    {formatTime(message.timestamp)}
                  </span>
                  <span className="text-xs font-medium text-primary">You</span>
                </>
              )}
            </div>

            {/* If this is a reply to another message, show the original message */}
            {message.replyTo && (
              <div 
                className={`text-xs text-muted-foreground p-1 px-2 mb-1 border rounded-md max-w-[200px] truncate cursor-pointer
                  ${isOwnMessage ? "bg-primary/5" : "bg-muted/50"}`}
                onClick={() => {
                  // Scroll to the original message if possible
                  const originalMessage = document.getElementById(`message-${message.replyTo?.id}`);
                  if (originalMessage) {
                    originalMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    // Highlight the message briefly
                    originalMessage.classList.add('highlight-message');
                    setTimeout(() => originalMessage.classList.remove('highlight-message'), 2000);
                  }
                }}
              >
                <span className="font-semibold">{message.replyTo.sender.name}:</span> {
                  message.replyTo.content.startsWith('data:image') 
                    ? '[Image]' 
                    : message.replyTo.content.length > 30 
                      ? message.replyTo.content.substring(0, 30) + '...' 
                      : message.replyTo.content
                }
              </div>
            )}

            <div 
              id={`message-${message.id}`}
              ref={messageRef}
              className={isOwnMessage ? "message-bubble-out" : "message-bubble-in"}
              onClick={handleMessageClick}
            >
              {renderMessageContent()}
            </div>

            {/* Display reactions if any */}
            {message.reactions && Object.keys(message.reactions).length > 0 && (
              <div className={`flex flex-wrap gap-1 mt-1 ${isOwnMessage ? "justify-end" : "justify-start"}`}>
                {Object.entries(message.reactions).map(([emoji, userIds]) => (
                  userIds.length > 0 && (
                    <button
                      key={emoji}
                      className={`px-1.5 py-0.5 rounded-full text-xs flex items-center gap-0.5 transition-colors
                        ${userIds.includes(currentUser.id) 
                          ? 'bg-primary/20 hover:bg-primary/30' 
                          : 'bg-muted hover:bg-muted/80'}`}
                      onClick={() => toggleReaction(emoji)}
                      title={userIds.map((id: string) => {
                        const userName = id === currentUser.id ? 'You' : 
                          messages.find((m: Message) => m.sender.id === id)?.sender.name || 'User';
                        return userName;
                      }).join(', ')}
                    >
                      <span>{emoji}</span>
                      <span className="text-muted-foreground ml-0.5">{userIds.length}</span>
                    </button>
                  )
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Message Actions - show on hover */}
        <div 
          className={`${
            isHovered ? "opacity-100" : "opacity-0"
          } transition-opacity flex items-center space-x-1 ${isOwnMessage ? "order-1" : "order-3"}`}
        >
          {isOwnMessage ? (
            <>
              <button 
                className="p-1 text-muted-foreground hover:text-foreground"
                onClick={() => handleMessageAction("delete")}
              >
                <Trash className="h-4 w-4" />
              </button>
            </>
          ) : (
            <>
              <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
                <PopoverTrigger asChild>
                  <button 
                    className="p-1 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                  >
                    <SmilePlus className="h-4 w-4" />
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-64 p-2">
                  <div className="grid grid-cols-8 gap-1">
                    {commonEmojis.map((emoji) => (
                      <button
                        key={emoji}
                        className="hover:bg-muted p-1 rounded"
                        onClick={() => handleEmojiSelect(emoji)}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
              <button 
                  className="p-1 text-muted-foreground hover:text-foreground"
                  onClick={() => handleMessageAction("reply")}
                >
                  <Reply className="h-4 w-4" />
                </button>
              <button 
                  className="p-1 text-muted-foreground hover:text-foreground"
                  onClick={() => handleMessageAction("whisper")}
                >
                  <MessageSquare className="h-4 w-4" />
                </button>

                {showPrivateMessageForm && (
                  <div className="absolute bottom-full right-0 mb-2 w-64 bg-background border rounded-lg shadow-lg p-2">
                    <form onSubmit={handlePrivateMessageSubmit}>
                      <input
                        type="text"
                        value={privateMessage}
                        onChange={(e) => setPrivateMessage(e.target.value)}
                        placeholder="Type private message..."
                        className="w-full p-2 border rounded mb-2"
                        autoFocus
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setShowPrivateMessageForm(false)}
                          className="px-2 py-1 text-sm text-muted-foreground hover:text-foreground"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-2 py-1 text-sm bg-primary text-primary-foreground rounded"
                        >
                          Send
                        </button>
                      </div>
                    </form>
                  </div>
                )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}