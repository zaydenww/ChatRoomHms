import { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Plus, Users } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useChatContext } from "@/context/ChatContext";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { generateId } from "@/lib/utils";
import { ActiveChatRoom } from "@shared/schema";

interface ChatRoomTabsProps {
  activeChatRoom: string;
  onChangeRoom: (roomId: string) => void;
}

export default function ChatRoomTabs({ activeChatRoom, onChangeRoom }: ChatRoomTabsProps) {
  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState(false);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [newChatName, setNewChatName] = useState("");
  const [inviteUserName, setInviteUserName] = useState("");
  const { user, chatRooms, createChatRoom, addUserToChatRoom } = useChatContext();
  const { toast } = useToast();

  const handleCreateNewChat = () => {
    if (!newChatName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a chat room name",
        variant: "destructive",
      });
      return;
    }

    const newRoomId = generateId();
    createChatRoom({
      id: newRoomId,
      name: newChatName,
      isPrivate: false,
      participants: [user.id],
    });

    setNewChatName("");
    setIsNewChatModalOpen(false);
    
    // Switch to the new chat room
    onChangeRoom(newRoomId);
    
    toast({
      title: "Chat created",
      description: `Created new chat room: ${newChatName}`,
    });
  };

  const handleInviteUser = () => {
    if (!inviteUserName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a username to invite",
        variant: "destructive",
      });
      return;
    }

    addUserToChatRoom(activeChatRoom, inviteUserName);
    setInviteUserName("");
    setIsInviteModalOpen(false);
    
    toast({
      title: "Invitation sent",
      description: `Invited ${inviteUserName} to this chat room`,
    });
  };

  return (
    <div className="p-1">
      <Tabs 
        value={activeChatRoom} 
        onValueChange={onChangeRoom}
        className="w-full"
      >
        <div className="flex items-center mb-1">
          <TabsList className="flex-1 overflow-x-auto no-scrollbar">
            {chatRooms.map((room) => (
              <TabsTrigger 
                key={room.id} 
                value={room.id}
                className="min-w-[100px] flex items-center gap-1"
              >
                <Users className="h-4 w-4" />
                <span className="truncate">{room.name}</span>
                {room.unreadCount > 0 && (
                  <Badge variant="destructive" className="h-5 w-5 flex items-center justify-center rounded-full p-0 text-xs">
                    {room.unreadCount}
                  </Badge>
                )}
              </TabsTrigger>
            ))}
          </TabsList>
          <Button 
            variant="outline" 
            size="icon" 
            className="ml-1"
            onClick={() => setIsNewChatModalOpen(true)}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </Tabs>

      {/* New Chat Modal */}
      <Dialog open={isNewChatModalOpen} onOpenChange={setIsNewChatModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create a new chat</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="name">Chat name</Label>
              <Input
                id="name"
                value={newChatName}
                onChange={(e) => setNewChatName(e.target.value)}
                placeholder="Enter chat name"
              />
            </div>
            <div className="flex justify-end gap-2">
              <DialogClose asChild>
                <Button variant="outline">Cancel</Button>
              </DialogClose>
              <Button onClick={handleCreateNewChat}>Create Chat</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Invite User Modal */}
      <Dialog open={isInviteModalOpen} onOpenChange={setIsInviteModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Invite user to chat</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={inviteUserName}
                onChange={(e) => setInviteUserName(e.target.value)}
                placeholder="Enter username to invite"
              />
            </div>
            <div className="flex justify-end gap-2">
              <DialogClose asChild>
                <Button variant="outline">Cancel</Button>
              </DialogClose>
              <Button onClick={handleInviteUser}>Invite</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}