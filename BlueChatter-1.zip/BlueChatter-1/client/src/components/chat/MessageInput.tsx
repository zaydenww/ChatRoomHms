import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Image, Send, Users, X, Reply, MessageSquare } from "lucide-react";
import { useChatContext } from "@/context/ChatContext";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface MessageInputProps {
  onNewChatClick?: () => void;
  chatRoomId: string;
}

export default function MessageInput({ onNewChatClick, chatRoomId }: MessageInputProps) {
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const lastTypingTime = useRef<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { 
    user, 
    socket, 
    sendMessage, 
    sendTypingStatus, 
    isUserRestricted, 
    replyingTo, 
    setReplyingTo,
    sendReplyMessage
  } = useChatContext();
  const { toast } = useToast();
  
  // Handle typing notification logic
  useEffect(() => {
    const TYPING_TIMER_LENGTH = 3000; // 3 seconds
    
    if (message && !isTyping) {
      setIsTyping(true);
      sendTypingStatus(true);
    }
    
    lastTypingTime.current = Date.now();
    
    const timer = setTimeout(() => {
      const timeNow = Date.now();
      const timeDiff = timeNow - lastTypingTime.current;
      
      if (timeDiff >= TYPING_TIMER_LENGTH && isTyping) {
        setIsTyping(false);
        sendTypingStatus(false);
      }
    }, TYPING_TIMER_LENGTH);
    
    return () => clearTimeout(timer);
  }, [message, isTyping, sendTypingStatus]);
  
  const handleSend = () => {
    if (!message.trim() && !fileInputRef.current?.files?.length) return;
    
    // Check if user is restricted
    if (isUserRestricted()) {
      toast({
        title: "You are restricted",
        description: "You cannot send messages at this time",
        variant: "destructive",
      });
      return;
    }
    
    // If replying to a message, send as a reply
    if (replyingTo) {
      sendReplyMessage(replyingTo.messageId, message, chatRoomId);
    } else {
      // Otherwise send as a normal message
      sendMessage(message, chatRoomId);
    }
    
    setMessage("");
    setIsTyping(false);
    sendTypingStatus(false);
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
  
  const handleImageClick = () => {
    fileInputRef.current?.click();
  };
  
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Check if user is restricted
    if (isUserRestricted()) {
      toast({
        title: "You are restricted",
        description: "You cannot send images at this time",
        variant: "destructive",
      });
      return;
    }
    
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file",
        description: "Please select an image file",
        variant: "destructive",
      });
      return;
    }
    
    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Uploading image...",
      description: "Please wait while your image is being processed.",
    });
    
    const reader = new FileReader();
    reader.onloadend = () => {
      try {
        const base64 = reader.result as string;
        sendMessage(base64, chatRoomId);
      } catch (error) {
        console.error("Error processing image:", error);
        toast({
          title: "Error uploading image",
          description: "There was a problem processing your image.",
          variant: "destructive",
        });
      }
    };
    
    reader.onerror = () => {
      toast({
        title: "Error uploading image",
        description: "There was a problem reading your image file.",
        variant: "destructive",
      });
    };
    
    reader.readAsDataURL(file);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Display reply info if replying to a message
  const renderReplyingTo = () => {
    if (!replyingTo) return null;
    
    return (
      <div className="px-4 pt-2 flex items-center justify-between">
        <div className="flex items-center text-xs text-muted-foreground">
          <Reply className="h-3 w-3 mr-1" />
          <span>Replying to <span className="font-semibold">{replyingTo.originalSenderName}</span>: {replyingTo.content.length > 50 ? replyingTo.content.substring(0, 50) + '...' : replyingTo.content}</span>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-5 w-5 p-0" 
          onClick={() => setReplyingTo(null)}
        >
          <X className="h-3 w-3" />
        </Button>
      </div>
    );
  };
  
  return (
    <div className="bg-card shadow-md border-t">
      {renderReplyingTo()}
      <div className="container mx-auto p-3">
        <div className="flex items-end space-x-2">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleImageClick}
            className="text-muted-foreground hover:text-primary"
          >
            <Image className="h-5 w-5" />
          </Button>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleImageChange} 
            accept="image/*" 
            className="hidden" 
          />
          
          <div className="flex-1 relative">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message..."
              className="min-h-[2.5rem] max-h-32 w-full resize-none rounded-xl"
              rows={1}
            />
            {Object.keys(useChatContext().typingUsers).some(id => id !== user.id) && (
              <div className="absolute bottom-2 right-2 text-xs text-muted-foreground">
                Someone is typing...
              </div>
            )}
          </div>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost"
                  size="icon" 
                  onClick={onNewChatClick}
                  className="text-muted-foreground hover:text-primary"
                >
                  <MessageSquare className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Create new chat</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <Button 
            size="icon" 
            onClick={handleSend} 
            className="rounded-full bg-blue-500 hover:bg-blue-600"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
