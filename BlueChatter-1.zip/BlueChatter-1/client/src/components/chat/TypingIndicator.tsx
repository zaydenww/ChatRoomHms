interface TypingIndicatorProps {
  userName: string;
}

export default function TypingIndicator({ userName }: TypingIndicatorProps) {
  return (
    <div className="flex justify-start space-x-2 mb-2 message-wrapper">
      <div className="max-w-xs">
        <div className="flex flex-col items-start">
          <span className="text-xs font-medium text-muted-foreground mb-1">{userName}</span>
          <div className="bg-gray-200 dark:bg-gray-700 p-3 rounded-2xl rounded-tl-sm flex space-x-1 items-center">
            <div className="typing-dot"></div>
            <div className="typing-dot"></div>
            <div className="typing-dot"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
