import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { useChatContext } from "@/context/ChatContext";
import { X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PrivateMessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipient: { id: string; name: string } | null;
}

export default function PrivateMessageModal({
  isOpen,
  onClose,
  recipient,
}: PrivateMessageModalProps) {
  const [privateMessage, setPrivateMessage] = useState("");
  const { sendPrivateMessage } = useChatContext();
  const { toast } = useToast();

  if (!recipient) return null;

  const handleSendPrivateMessage = () => {
    if (!privateMessage.trim()) {
      toast({
        title: "Empty message",
        description: "Please enter a message to send",
        variant: "destructive",
      });
      return;
    }

    sendPrivateMessage(recipient.id, privateMessage);
    
    toast({
      title: "Private message sent",
      description: `Your message has been sent to ${recipient.name}`,
    });
    
    setPrivateMessage("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium">
            Send private message to {recipient.name}
          </DialogTitle>
          <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </DialogClose>
        </DialogHeader>
        
        <Textarea
          value={privateMessage}
          onChange={(e) => setPrivateMessage(e.target.value)}
          placeholder="Type your private message..."
          className="min-h-[100px]"
        />
        
        <DialogFooter>
          <Button onClick={handleSendPrivateMessage} className="w-full">
            Send Private Message
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
