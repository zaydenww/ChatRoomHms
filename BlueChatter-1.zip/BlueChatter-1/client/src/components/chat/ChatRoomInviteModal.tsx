import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useChatContext } from "@/context/ChatContext";
import { useToast } from "@/hooks/use-toast";

interface ChatRoomInviteModalProps {
  isOpen: boolean;
  onClose: () => void;
  chatRoomId: string;
  chatRoomName: string;
}

export default function ChatRoomInviteModal({ 
  isOpen, 
  onClose, 
  chatRoomId,
  chatRoomName
}: ChatRoomInviteModalProps) {
  const [inviteUserName, setInviteUserName] = useState("");
  const { addUserToChatRoom } = useChatContext();
  const { toast } = useToast();

  const handleInviteUser = () => {
    if (!inviteUserName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a username to invite",
        variant: "destructive",
      });
      return;
    }

    addUserToChatRoom(chatRoomId, inviteUserName);
    setInviteUserName("");
    onClose();
    
    toast({
      title: "Invitation sent",
      description: `Invited ${inviteUserName} to ${chatRoomName}`,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Invite user to {chatRoomName}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              value={inviteUserName}
              onChange={(e) => setInviteUserName(e.target.value)}
              placeholder="Enter username to invite"
              autoComplete="off"
            />
          </div>
          <div className="flex justify-end gap-2">
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button onClick={handleInviteUser}>Invite</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}