import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email().optional(),
});
import { useChatContext } from "@/context/ChatContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Form schema for profile information
const profileSchema = z.object({
  email: z
    .string()
    .email("Invalid email format")
    .optional()
    .or(z.literal("")),
  username: z
    .string()
    .min(2, "Username must be at least 2 characters")
    .max(30, "Username must be less than 30 characters"),
  saveChats: z
    .boolean()
    .default(true)
});

type ProfileFormData = z.infer<typeof profileSchema>;

export default function ProfileModal({ isOpen, onClose }: ProfileModalProps) {
  const { user, changeOwnName, setAdmin } = useChatContext(); // Added setAdmin
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState(user.name);
  const [saveChats, setSaveChats] = useState(true);

  // Initialize the form
  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      email: email,
      username: username,
      saveChats: saveChats
    }
  });

  // Update form when values change
  useEffect(() => {
    form.reset({ 
      email,
      username,
      saveChats
    });
  }, [email, username, saveChats, form]);

  // Load the user's saved data from localStorage on component mount
  useEffect(() => {
    // Load email
    const savedEmail = localStorage.getItem(`user_${user.id}_email`);
    if (savedEmail) {
      setEmail(savedEmail);
    }

    // Load save chats preference
    const savedChatsPref = localStorage.getItem(`user_${user.id}_saveChats`);
    if (savedChatsPref !== null) {
      setSaveChats(savedChatsPref === 'true');
    }
  }, [user.id]);

  // Handle form submission
  const onSubmit = (data: ProfileFormData) => {
    // Save email to localStorage
    localStorage.setItem(`user_${user.id}_email`, data.email || ""); // Handle null email
    setEmail(data.email || "");

    // Save username - update state and context
    if (data.username !== user.name) {
      changeOwnName(data.username);
      setUsername(data.username);
      localStorage.setItem(`user_${user.id}_username`, data.username);
    }

    // Save chat preference
    localStorage.setItem(`user_${user.id}_saveChats`, data.saveChats.toString());
    setSaveChats(data.saveChats);

    // If save chats is enabled, store current messages and chat rooms
    if (data.saveChats) {
      try {
        // We'll save chat data that will be loaded on next login
        const chatHistory = {
          lastSeen: new Date().toISOString(),
          userId: user.id
        };
        localStorage.setItem(`chat_history_${user.id}`, JSON.stringify(chatHistory));
      } catch (error) {
        console.error("Failed to save chat history:", error);
      }
    }

    const adminEmails = ["zaydenwattsyt@gmail.com", "rtavant722@dcsdschools.org"];
    if (adminEmails.includes(data.email || "")) {
      setAdmin(true);
    } else {
      setAdmin(false);
    }


    // Show success message
    toast({
      title: "Profile Updated",
      description: "Your profile settings have been saved successfully.",
      variant: "default",
    });

    // Close the modal
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Profile Settings</DialogTitle>
          <DialogDescription>
            Manage your account information and email preferences.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Display Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Your display name" {...field} />
                  </FormControl>
                  <FormDescription>
                    This is the name that will be shown to others in the chat.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address (optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="you@example.com" type="email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="saveChats"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Save Chat History</FormLabel>
                    <FormDescription>
                      Keep your chat rooms and message history when you return
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <DialogFooter className="pt-4">
              <Button variant="outline" type="button" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit">Save Changes</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}