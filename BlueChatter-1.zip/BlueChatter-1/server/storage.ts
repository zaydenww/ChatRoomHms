import { 
  messages, 
  type Message, 
  type InsertMessage, 
  users, 
  type User, 
  type InsertUser, 
  type Reactions, 
  type ChatRoom, 
  type InsertChatRoom, 
  chatRooms 
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByName(name: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserName(id: string, newName: string): Promise<User | undefined>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessage(id: string): Promise<Message | undefined>;
  getUserMessages(userId: string): Promise<Message[]>;
  getAllMessages(): Promise<Message[]>;
  getChatRoomMessages(chatRoomId: string): Promise<Message[]>;
  deleteMessage(id: string): Promise<boolean>;
  deleteUserMessages(userId: string): Promise<boolean>;
  
  // Reaction operations
  addReaction(messageId: string, emoji: string, userId: string): Promise<boolean>;
  removeReaction(messageId: string, emoji: string, userId: string): Promise<boolean>;
  getMessageReactions(messageId: string): Promise<Reactions>;
  
  // Reply operations
  createReply(messageId: string, replyToId: string): Promise<boolean>;
  getMessageReplies(messageId: string): Promise<Message[]>;
  
  // Chat Room operations
  createChatRoom(chatRoom: InsertChatRoom): Promise<ChatRoom>;
  getChatRoom(id: string): Promise<ChatRoom | undefined>;
  getAllChatRooms(): Promise<ChatRoom[]>;
  getUserChatRooms(userId: string): Promise<ChatRoom[]>;
  addUserToChatRoom(chatRoomId: string, userId: string): Promise<boolean>;
  removeUserFromChatRoom(chatRoomId: string, userId: string): Promise<boolean>;
  deleteChatRoom(id: string): Promise<boolean>;
  
  // Misc operations
  getUsers(): Promise<User[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private messages: Map<string, Message>;
  private chatRooms: Map<string, ChatRoom>;

  constructor() {
    this.users = new Map();
    this.messages = new Map();
    this.chatRooms = new Map();
    
    // Create a default general chat room
    this.chatRooms.set("general", {
      id: "general",
      name: "General",
      createdBy: "system",
      timestamp: new Date(),
      isPrivate: false,
      participants: []
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByName(name: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.name.toLowerCase() === name.toLowerCase()
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    this.users.set(user.id, user as User);
    return user as User;
  }

  async updateUserName(id: string, newName: string): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, name: newName };
    this.users.set(id, updatedUser);
    
    // Update message sender names
    // Convert to array first to avoid iterator issues
    Array.from(this.messages.entries()).forEach(([messageId, message]) => {
      if (message.senderId === id) {
        this.messages.set(messageId, {
          ...message,
          senderName: newName,
          sender: {
            ...message.sender,
            name: newName
          }
        });
      }
    });
    
    return updatedUser;
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const completeMessage = {
      ...message,
      sender: {
        id: message.senderId,
        name: message.senderName
      }
    } as Message;
    
    this.messages.set(message.id, completeMessage);
    return completeMessage;
  }

  async getMessage(id: string): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async getUserMessages(userId: string): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => message.senderId === userId
    );
  }

  async getAllMessages(): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => !message.isPrivate
    ).sort((a, b) => {
      return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
    });
  }

  async deleteMessage(id: string): Promise<boolean> {
    return this.messages.delete(id);
  }

  async deleteUserMessages(userId: string): Promise<boolean> {
    let success = true;
    
    // Convert to array first to avoid iterator issues
    Array.from(this.messages.entries()).forEach(([messageId, message]) => {
      if (message.senderId === userId) {
        const deleted = this.messages.delete(messageId);
        if (!deleted) success = false;
      }
    });
    
    return success;
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  // Reaction methods
  async addReaction(messageId: string, emoji: string, userId: string): Promise<boolean> {
    const message = await this.getMessage(messageId);
    if (!message) return false;
    
    // Create a copy of the existing reactions
    const reactions = { ...(message.reactions as Reactions) };
    
    // Add user to the emoji's reaction list
    if (!reactions[emoji]) {
      reactions[emoji] = [];
    }
    
    // Don't add duplicate reactions
    if (!reactions[emoji].includes(userId)) {
      reactions[emoji].push(userId);
    }
    
    // Update message
    this.messages.set(messageId, {
      ...message,
      reactions
    });
    
    return true;
  }
  
  async removeReaction(messageId: string, emoji: string, userId: string): Promise<boolean> {
    const message = await this.getMessage(messageId);
    if (!message) return false;
    
    // Create a copy of the existing reactions
    const reactions = { ...(message.reactions as Reactions) };
    
    // Remove user from the emoji's reaction list
    if (reactions[emoji] && reactions[emoji].includes(userId)) {
      reactions[emoji] = reactions[emoji].filter(id => id !== userId);
      
      // Remove empty reaction arrays
      if (reactions[emoji].length === 0) {
        delete reactions[emoji];
      }
      
      // Update message
      this.messages.set(messageId, {
        ...message,
        reactions
      });
      
      return true;
    }
    
    return false;
  }
  
  async getMessageReactions(messageId: string): Promise<Reactions> {
    const message = await this.getMessage(messageId);
    if (!message) return {};
    
    return message.reactions as Reactions;
  }
  
  // Reply methods
  async createReply(messageId: string, replyToId: string): Promise<boolean> {
    const message = await this.getMessage(messageId);
    const replyToMessage = await this.getMessage(replyToId);
    
    if (!message || !replyToMessage) return false;
    
    // Update the message with the reply reference
    this.messages.set(messageId, {
      ...message,
      replyToId
    });
    
    return true;
  }
  
  async getMessageReplies(messageId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.replyToId === messageId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }
  
  // ChatRoom methods
  async createChatRoom(chatRoom: InsertChatRoom): Promise<ChatRoom> {
    const newChatRoom = chatRoom as ChatRoom;
    this.chatRooms.set(chatRoom.id, newChatRoom);
    return newChatRoom;
  }
  
  async getChatRoom(id: string): Promise<ChatRoom | undefined> {
    return this.chatRooms.get(id);
  }
  
  async getAllChatRooms(): Promise<ChatRoom[]> {
    return Array.from(this.chatRooms.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
  
  async getUserChatRooms(userId: string): Promise<ChatRoom[]> {
    return Array.from(this.chatRooms.values())
      .filter(chatRoom => 
        // Include both public rooms and private rooms the user is part of
        !chatRoom.isPrivate || 
        (chatRoom.participants as string[]).includes(userId) ||
        chatRoom.createdBy === userId
      )
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
  
  async addUserToChatRoom(chatRoomId: string, userId: string): Promise<boolean> {
    const chatRoom = await this.getChatRoom(chatRoomId);
    if (!chatRoom) return false;
    
    // Create a copy of the participants array
    const participants = [...(chatRoom.participants as string[])];
    
    // Add user if not already a participant
    if (!participants.includes(userId)) {
      participants.push(userId);
      
      // Update chat room
      this.chatRooms.set(chatRoomId, {
        ...chatRoom,
        participants
      });
    }
    
    return true;
  }
  
  async removeUserFromChatRoom(chatRoomId: string, userId: string): Promise<boolean> {
    const chatRoom = await this.getChatRoom(chatRoomId);
    if (!chatRoom) return false;
    
    // Create a copy of the participants array
    const participants = [...(chatRoom.participants as string[])];
    
    // Remove user from participants
    const updatedParticipants = participants.filter(id => id !== userId);
    
    // Update chat room
    this.chatRooms.set(chatRoomId, {
      ...chatRoom,
      participants: updatedParticipants
    });
    
    return true;
  }
  
  async deleteChatRoom(id: string): Promise<boolean> {
    // Don't allow deleting the general chat room
    if (id === "general") return false;
    return this.chatRooms.delete(id);
  }
  
  async getChatRoomMessages(chatRoomId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.chatRoomId === chatRoomId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }
}

export const storage = new MemStorage();
