import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { generateId } from "../client/src/lib/utils";

interface Client {
  userId: string;
  userName: string;
  email?: string;
  isAdmin: boolean;
  ws: WebSocket;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Set up WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Track connected clients
  const clients: Client[] = [];
  
  // Handle WebSocket connections
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    // Handle messages
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        await handleWebSocketMessage(ws, data, clients);
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    });
    
    // Handle disconnection
    ws.on('close', () => {
      const index = clients.findIndex(client => client.ws === ws);
      
      if (index !== -1) {
        const { userId, userName } = clients[index];
        console.log(`User disconnected: ${userName} (${userId})`);
        
        // Broadcast user leave message
        const leaveMessage = {
          type: 'user_leave',
          data: {
            userId,
            name: userName
          }
        };
        
        broadcastMessage(clients, leaveMessage, ws);
        
        // Remove client from list
        clients.splice(index, 1);
      }
    });
  });
  
  return httpServer;
}

// WebSocket message handler
async function handleWebSocketMessage(ws: WebSocket, data: any, clients: Client[]) {
  switch (data.type) {
    case 'add_reaction':
      const { messageId: reactionMessageId, emoji, userId: reactingUserId } = data.data;
      
      // Add reaction to the message
      const reactionAdded = await storage.addReaction(reactionMessageId, emoji, reactingUserId);
      
      if (reactionAdded) {
        // Get updated reactions
        const updatedReactions = await storage.getMessageReactions(reactionMessageId);
        
        // Broadcast reaction update to all clients
        broadcastMessage(clients, {
          type: 'update_reactions',
          data: {
            messageId: reactionMessageId,
            reactions: updatedReactions
          }
        });
      }
      break;
      
    case 'remove_reaction':
      const { messageId: removeReactionMessageId, emoji: removeEmoji, userId: removingUserId } = data.data;
      
      // Remove reaction from the message
      const reactionRemoved = await storage.removeReaction(removeReactionMessageId, removeEmoji, removingUserId);
      
      if (reactionRemoved) {
        // Get updated reactions
        const updatedReactions = await storage.getMessageReactions(removeReactionMessageId);
        
        // Broadcast reaction update to all clients
        broadcastMessage(clients, {
          type: 'update_reactions',
          data: {
            messageId: removeReactionMessageId,
            reactions: updatedReactions
          }
        });
      }
      break;
      
    case 'reply_message':
      const { replyToId, messageData: replyMessageData } = data.data;
      const replyMessageId = generateId();
      const replyTimestamp = new Date();
      
      // Create the reply message in storage, with chatRoomId
      const newReplyMessage = await storage.createMessage({
        id: replyMessageId,
        content: replyMessageData.content,
        senderId: replyMessageData.sender.id,
        senderName: replyMessageData.sender.name,
        timestamp: replyTimestamp,
        isPrivate: false,
        replyToId,
        chatRoomId: replyMessageData.chatRoomId || 'general' // Use the chat room ID from the client or default to 'general'
      });
      
      // Link the message to the original
      await storage.createReply(replyMessageId, replyToId);
      
      // Get the original message for reference
      const originalMessage = await storage.getMessage(replyToId);
      
      if (originalMessage) {
        // Attach reply info to the message
        const messageWithReplyInfo = {
          ...newReplyMessage,
          replyTo: {
            id: originalMessage.id,
            content: originalMessage.content,
            sender: {
              id: originalMessage.senderId,
              name: originalMessage.senderName
            }
          }
        };
        
        // Broadcast reply to all clients
        broadcastMessage(clients, {
          type: 'message',
          data: messageWithReplyInfo
        });
      }
      break;
    case 'join':
      // Register new user
      const { userId, name, isAdmin } = data.data;
      
      // Store user in database
      await storage.createUser({
        id: userId,
        name,
        isAdmin
      });
      
      // Add client to connected clients
      clients.push({
        userId,
        userName: name,
        isAdmin,
        ws
      });
      
      // Send existing messages to the new user
      const existingMessages = await storage.getAllMessages();
      existingMessages.forEach(message => {
        ws.send(JSON.stringify({
          type: 'message',
          data: message
        }));
      });
      
      // Broadcast join message
      broadcastMessage(clients, {
        type: 'user_join',
        data: {
          userId,
          name
        }
      });
      
      console.log(`User joined: ${name} (${userId}), isAdmin: ${isAdmin}`);
      break;
      
    case 'message':
      const messageData = data.data;
      const messageId = generateId();
      const timestamp = new Date();
      
      // Create message in storage, now with chatRoomId
      const newMessage = await storage.createMessage({
        id: messageId,
        content: messageData.content,
        senderId: messageData.sender.id,
        senderName: messageData.sender.name,
        timestamp,
        isPrivate: false,
        chatRoomId: messageData.chatRoomId || 'general' // Use the chat room ID from the client or default to 'general'
      });
      
      // Broadcast message to all clients
      broadcastMessage(clients, {
        type: 'message',
        data: newMessage
      });
      break;
      
    case 'private_message':
      const privateMessageData = data.data;
      const privateMessageId = generateId();
      const privateTimestamp = new Date();
      
      // Find recipient client
      const recipient = clients.find(client => client.userId === privateMessageData.recipientId);
      const sender = clients.find(client => client.userId === privateMessageData.senderId);
      
      if (recipient && sender) {
        // Store private message
        await storage.createMessage({
          id: privateMessageId,
          content: privateMessageData.content,
          senderId: privateMessageData.senderId,
          senderName: privateMessageData.senderName,
          timestamp: privateTimestamp,
          isPrivate: true,
          recipientId: privateMessageData.recipientId
        });
        
        // Send to recipient
        recipient.ws.send(JSON.stringify({
          type: 'private_message',
          data: {
            ...privateMessageData,
            recipientName: recipient.userName
          }
        }));
        
        // Confirm to sender
        sender.ws.send(JSON.stringify({
          type: 'private_message',
          data: {
            ...privateMessageData,
            recipientName: recipient.userName
          }
        }));
      }
      break;
      
    case 'typing':
      // Broadcast typing status to all clients
      broadcastMessage(clients, data);
      break;
      
    case 'delete_message':
      const { messageId: deleteMessageId, userId: deletingUserId, isAdmin: isAdminDeleting } = data.data;
      
      // Get message to check permissions
      const messageToDelete = await storage.getMessage(deleteMessageId);
      
      // Get the client to check if they're named "Zayden"
      const deletingClient = clients.find(client => client.userId === deletingUserId);
      const isNamedZayden = deletingClient && deletingClient.userName.toLowerCase() === 'zayden';
      
      if (messageToDelete) {
        // Allow deletion if user is the sender or is named Zayden
        if (messageToDelete.senderId === deletingUserId || isNamedZayden) {
          await storage.deleteMessage(deleteMessageId);
          
          // Broadcast deletion to all clients
          broadcastMessage(clients, {
            type: 'delete_message',
            data: {
              messageId: deleteMessageId
            }
          });
        }
      }
      break;
      
    case 'user_leave':
      const leavingClient = clients.find(client => client.userId === data.data.userId);
      
      if (leavingClient) {
        // Broadcast leave message to other clients
        broadcastMessage(clients, data, leavingClient.ws);
        
        // Remove client from list
        const index = clients.indexOf(leavingClient);
        clients.splice(index, 1);
      }
      break;
      
    case 'restrict_user':
      const { userId: restrictedUserId, durationSeconds, adminId } = data.data;
      
      // Verify admin status - must be named "Zayden" (case insensitive)
      const adminClient = clients.find(client => client.userId === adminId);
      
      if (adminClient && adminClient.userName.toLowerCase() === 'zayden222') {
        // Find the user to restrict
        const userToRestrict = clients.find(client => client.userId === restrictedUserId);
        
        if (userToRestrict) {
          // Send restriction notice to the user
          userToRestrict.ws.send(JSON.stringify({
            type: 'restrict_user',
            data: {
              userId: restrictedUserId,
              durationSeconds
            }
          }));
        }
      }
      break;
      
    case 'name_change':
      const { userId: changingUserId, newName, adminId: nameChangeAdminId, self, oldName } = data.data;
      
      // Verify permissions (admin named "Zayden" or self)
      const requestingClient = clients.find(client => 
        (nameChangeAdminId && client.userId === nameChangeAdminId && client.userName.toLowerCase() === 'zayden') || 
        (self && client.userId === changingUserId)
      );
      
      if (requestingClient) {
        // Update user name in storage
        const updatedUser = await storage.updateUserName(changingUserId, newName);
        
        if (updatedUser) {
          // Update client list
          const clientToUpdate = clients.find(client => client.userId === changingUserId);
          if (clientToUpdate) {
            clientToUpdate.userName = newName;
            
            // Check if this is becoming an admin (name changed to "zayden222")
            if (newName === 'zayden222') {
              clientToUpdate.isAdmin = true;
            } else if (oldName === 'zayden222') {
              clientToUpdate.isAdmin = false;
            }
          }
          
          // Broadcast name change to all clients
          broadcastMessage(clients, {
            type: 'name_change',
            data: {
              userId: changingUserId,
              oldName: oldName || (clientToUpdate?.userName || 'Unknown'),
              newName
            }
          });
        }
      }
      break;
      
    case 'delete_user_messages':
      const { userId: userToDeleteMessages, adminId: deletingAdminId } = data.data;
      
      // Verify admin status based on email
      const deletingAdmin = clients.find(client => client.userId === deletingAdminId);
      const adminEmails = ['zaydenwattsyt@gmail.com', 'rtavant722@dcsdschools.org'];
      
      if (deletingAdmin && deletingAdmin.email && adminEmails.includes(deletingAdmin.email)) {
        // Get all messages from user
        const userMessages = await storage.getUserMessages(userToDeleteMessages);
        
        // Delete all messages
        await storage.deleteUserMessages(userToDeleteMessages);
        
        // Broadcast deletion for each message
        userMessages.forEach(message => {
          broadcastMessage(clients, {
            type: 'delete_message',
            data: {
              messageId: message.id
            }
          });
        });
      }
      break;
      
    case 'create_chat_room':
      const { id: chatRoomId, name: chatRoomName, isPrivate, participants, creatorId, creatorName } = data.data;
      
      // Create the chat room
      await storage.createChatRoom({
        id: chatRoomId,
        name: chatRoomName,
        createdBy: creatorId,
        timestamp: new Date(),
        isPrivate: !!isPrivate,
        participants: participants || []
      });
      
      // Broadcast chat room creation to all clients
      broadcastMessage(clients, {
        type: 'chat_room_created',
        data: {
          id: chatRoomId,
          name: chatRoomName,
          createdBy: creatorId,
          creatorName,
          isPrivate: !!isPrivate,
          participants: participants || [],
          timestamp: new Date()
        }
      });
      break;
      
    case 'invite_to_chat_room':
      const { chatRoomId: inviteChatRoomId, inviterName, inviterId, inviteeName } = data.data;
      
      // Find the user being invited
      const invitee = clients.find(client => client.userName === inviteeName);
      const inviter = clients.find(client => client.userId === inviterId);
      
      if (invitee && inviter) {
        // Get the chat room
        const chatRoom = await storage.getChatRoom(inviteChatRoomId);
        
        if (chatRoom) {
          // Add user to the chat room
          await storage.addUserToChatRoom(inviteChatRoomId, invitee.userId);
          
          // Notify the invited user
          invitee.ws.send(JSON.stringify({
            type: 'chat_room_invitation',
            data: {
              chatRoomId: inviteChatRoomId,
              chatRoomName: chatRoom.name,
              inviterId,
              inviterName
            }
          }));
          
          // Confirm to inviter
          inviter.ws.send(JSON.stringify({
            type: 'chat_room_invitation_sent',
            data: {
              chatRoomId: inviteChatRoomId,
              chatRoomName: chatRoom.name,
              inviteeName,
              inviteeId: invitee.userId
            }
          }));
        }
      }
      break;
      
    default:
      console.log('Unknown message type:', data.type);
  }
}

// Broadcast message to all clients except the excluded one
function broadcastMessage(clients: Client[], message: any, exclude?: WebSocket) {
  clients.forEach(client => {
    if (client.ws !== exclude && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(JSON.stringify(message));
    }
  });
}
